bot_token = "5073846144:AAFJ-COnC6JE0DzuGXrdULdjn-10TjL6KTY"
qiwi_number = "+79581373212"
bitcoin_adress = "399LrqzF5upRDiHt3DQgGzWtC3jMqPpQNp"